package com.example.finalproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class airplanes extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_airplanes);
        ArrayList<airnames> array=new ArrayList<>();
        airnames one=new airnames(R.drawable.qqq,"kuwait airways");
        airnames two=new airnames(R.drawable.qatarl,"qatar airways");
        airnames three=new airnames(R.drawable.etihad,"etihad airways");
        airnames four=new airnames(R.drawable.asia,"air asia");
        airnames five=new airnames(R.drawable.emirates,"emirates airways");
        airnames six=new airnames(R.drawable.british,"british airways");
        airnames seven=new airnames(R.drawable.delta,"delta airways");
        array.add(one);
        array.add(two);
        array.add(three);
        array.add(four);
        array.add(five);
        array.add(six);
        array.add(seven);
        RecyclerView recyclerView=findViewById(R.id.recycler);
        recyclerView.setHasFixedSize(true);
        RecyclerView.LayoutManager lm=new LinearLayoutManager(this);
        recyclerView.setLayoutManager(lm);


        adapter p=new adapter(array,this);
        recyclerView.setAdapter(p);

    }
}