package com.example.finalproject;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class adapter2 extends RecyclerView.Adapter {

    ArrayList<flightname>flights;
    Context context1;

    public adapter2(ArrayList<flightname> flights, Context context) {
        this.flights = flights;
        this.context1 = context;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View m = LayoutInflater.from(parent.getContext()).inflate(R.layout.flight,parent,false);
        ViewHolder vh2=new ViewHolder(m);
        return vh2;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        ((ViewHolder)holder).date.setText(flights.get(position).getDate());
        ((ViewHolder)holder).time.setText(flights.get(position).getTime());
        ((ViewHolder)holder).img.setImageResource(R.drawable.qqq);
        final String date11= flights.get(position).getDate().toString();
        final String time12= flights.get(position).getTime().toString();
        ((ViewHolder)holder).view2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(context1,the_link.class);
                intent.putExtra("date",date11);
                intent.putExtra("time",time12);
                context1.startActivity(intent);
            }
        });



    }

    @Override
    public int getItemCount() {
        return flights.size();
    }
    public static class ViewHolder extends RecyclerView.ViewHolder{

        public TextView date;
        public TextView time;
        public View view2;
        public ImageView img;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            view2=itemView;
            date=itemView.findViewById(R.id.date);
            time=itemView.findViewById(R.id.time);
            img=itemView.findViewById(R.id.theimg);

        }
    }
}
