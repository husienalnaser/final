package com.example.finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class the_link extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_the_link);
        Button link=findViewById(R.id.website);
        TextView timee=findViewById(R.id.time1);
        TextView datee=findViewById(R.id.date1);
        Bundle b=getIntent().getExtras();

        datee.setText(b.getString("date"));
        timee.setText(b.getString("time"));




        link.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(the_link.this,end.class);
                startActivity(intent);
            }
        });
    }
}