package com.example.finalproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class login extends AppCompatActivity {

FirebaseAuth fAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        final EditText maily=findViewById(R.id.maily);
        final EditText passy=findViewById(R.id.passy);
        Button login=findViewById(R.id.login);
        final ProgressBar progg=findViewById(R.id.progressBar2);
        fAuth =FirebaseAuth.getInstance();
        final info husien1=new info();
        TextView signupp=findViewById(R.id.signupp);
        signupp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(com.example.finalproject.login.this,sign.class);
                startActivity(intent);
            }
        });



       login.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               String email=maily.getText().toString().trim();
               String password=passy.getText().toString().trim();

               if(TextUtils.isEmpty(email)){
                   maily.setError("name is required");
                   return;
               }
               if(TextUtils.isEmpty(password)){
                   passy.setError("password is required");
               }
               if(password.length()<6){
                   passy.setError("password is too short / must be > 6 characters");
                   return;
               }


               progg.setVisibility(View.VISIBLE);





               fAuth.signInWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                   @Override
                   public void onComplete(@NonNull Task<AuthResult> task) {
                       if(task.isSuccessful()){
                           Toast.makeText(login.this, "logged in", Toast.LENGTH_SHORT).show();
                           startActivity(new Intent(getApplicationContext(),mainpage.class));
                       }else{
                           Toast.makeText(login.this, "Error !"+task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                       }
                   }
               });
           }
       });





    }
}