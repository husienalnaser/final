package com.example.finalproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.ImageView;

import java.util.ArrayList;

public class flights extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_flights);
        ImageView img=findViewById(R.id.theimg);

        ArrayList<flightname> arrayList=new ArrayList<>();
        flightname one=new flightname("december 3rd","11:30");
        flightname two =new flightname("november 11th","1:00");
        flightname three =new flightname("febuary 8th","12:00");
        flightname four =new flightname("november 4th","8:00");
        flightname five =new flightname("august 22th","1:30");
        flightname six =new flightname("july 10th","9:00");
        flightname seven =new flightname("june 3rd","3:00");
        flightname eight =new flightname("january 2nd","7:00");
        arrayList.add(one);
        arrayList.add(two);
        arrayList.add(three);
        arrayList.add(four);
        arrayList.add(five);
        arrayList.add(six);
        arrayList.add(seven);
        arrayList.add(eight);





//        Bundle b=getIntent().getExtras();
//        img.setImageResource(b.getInt("image"));


        RecyclerView recyclerView=findViewById(R.id.recycler1);
        recyclerView.setHasFixedSize(true);
        RecyclerView.LayoutManager lm=new LinearLayoutManager(this);
        recyclerView.setLayoutManager(lm);

        adapter2 m=new adapter2(arrayList,this);
        recyclerView.setAdapter(m);





    }
}