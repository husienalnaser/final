package com.example.finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class settings extends AppCompatActivity {
    FirebaseAuth fAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        final TextView showe=findViewById(R.id.emailshow);
        TextView shown=findViewById(R.id.change);
        fAuth= FirebaseAuth.getInstance();
        final TextView name=findViewById(R.id.nameshow);
        final TextView pass=findViewById(R.id.passshow);
        Button signout=findViewById(R.id.signout);
        info name2=new info();



        name2.getName();
        name2.getPassword();
        name.setText(name2.getName());
        pass.setText( "pass : "+ name2.getPassword());






        signout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                name.setText("");
                pass.setText("");
                showe.setText("no account ");

                final int SPLASH_DISPLAY_LENGTH = 1000;
                    new Handler().postDelayed(new Runnable(){
                        @Override
                        public void run() {
                            /* Create an Intent that will start the Menu-Activity. */
                            Intent mainIntent = new Intent(settings.this,login.class);
                            settings.this.startActivity(mainIntent);
                            settings.this.finish();
                        }
                    }, SPLASH_DISPLAY_LENGTH);




            }
        });








        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        String userEmail = user.getEmail();
        showe.setText(userEmail);





        shown.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(settings.this,login.class);
                startActivity(intent);
            }
        });

    }
}