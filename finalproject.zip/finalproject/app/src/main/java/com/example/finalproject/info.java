package com.example.finalproject;

public class info {
    private static String name;
    private static String password;
    private static String name2;
    private static String password2;



    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public static String getName2() {
        return name2;
    }

    public static void setName2(String name2) {
        info.name2 = name2;
    }

    public static String getPassword2() {
        return password2;
    }

    public static void setPassword2(String password2) {
        info.password2 = password2;
    }
}
